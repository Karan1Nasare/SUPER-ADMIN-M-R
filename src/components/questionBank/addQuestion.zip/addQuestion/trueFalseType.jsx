import React, { useState } from 'react';
import { RHFTextField } from '../../../hooks/hook-form';
import { RHFCheckbox } from '../../../hooks/hook-form/RHFCheckbox';

const TrueFalseType = props => {
  const [trueChecked, setTrueChecked] = useState(false);
  const [falseChecked, setFalseChecked] = useState(false);
  const { questionListForm } = props;
  const { setValue } = questionListForm;

  // const handleTrueChange = () => {
  //   setValue(`questions[${index}].details.options.options1`, 'True');
  //   setValue(`questions[${index}].details.options.options2`, 'False');
  // };

  // const handleFalseChange = () => {
  //   setValue(`questions[${index}].details.options.options1`, 'False');
  //   setValue(`questions[${index}].details.options.options2`, 'True');
  // };

  return (
    <div>
      <div className='text-white flex mt-5 ml-[6%]'>
        <h3 className='text-lg mt-2'>1.</h3>
        <RHFTextField
          className='bg-blue border border-gray-700 h-10 ml-4 w-[70%] text-xs p-2'
          type='text'
          name='question'
          id='question'
          // control={questionListForm.control}
          placeholder='Enter question text'
        />
      </div>
      <div className='ml-[7%]'>
        <h3 className='text-left text-base mt-5'>Options</h3>
        <div className='flex mt-4'>
          <RHFCheckbox
            name={`option`}
            id={`option`}
            value={1}
            onChange={() => {
              setValue('option', 1);
            }}
          />
          <h3 className='mt-2 text-sm ml-3'>True</h3>
        </div>
        <div className='flex mt-4'>
          <RHFCheckbox
            name={`option`}
            id={`option`}
            value={2}
            onChange={() => {
              setValue('option', 2);
            }}
          />
          <h3 className='mt-2 text-sm  ml-3'>False</h3>
        </div>
      </div>
    </div>
  );
};

export default TrueFalseType;
