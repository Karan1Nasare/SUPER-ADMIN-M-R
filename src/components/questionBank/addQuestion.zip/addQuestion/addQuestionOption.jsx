import React, { useState } from 'react';
import { useFormContext } from 'react-hook-form';
import SummaryType from './summaryType';
import TrueFalseType from './trueFalseType';
import McqType from './mcqType';
import { RHFTextField } from '../../../hooks/hook-form';
import { useStore } from '../../../store/context-store';

const AddQuestionOption = props => {
  const [Store, StoreDispatch] = useStore();
  const [selectedQuestionType, setSelectedQuestionType] = useState(null);
  const { questionListForm } = props;
  const { setValue } = questionListForm;
  console.log('setValues', setValue, questionListForm);
  const handleQuestionType = option => {
    setValue('question_type', option);
    setSelectedQuestionType(option);
    // setValue(`questions[${index}].type`, option);
  };

  return (
    <div className=' w-5/12 rounded-md border border-gray-700 p-8 bg-secondary__fill'>
      <div className='flex ml-[10%] mt-6'>
        <button
          className={`w-36 h-9 text-xs mr-5 rounded-sm bg-primary text-orange__primary  hover:text-success hover:bg-success hover:bg-opacity-15 ${selectedQuestionType === 'summary' ? 'bg-success bg-opacity-15 text-success' : 'text-orange bg-orange bg-opacity-15'}`}
          onClick={() => handleQuestionType('summary')}
          type='button'
        >
          Summary
        </button>
        <button
          className={`w-36 h-9 text-xs mr-5 rounded-sm bg-primary text-orange__primary  hover:text-success hover:bg-success hover:bg-opacity-15 ${selectedQuestionType === 'mcq' ? 'bg-success bg-opacity-15 text-success' : 'text-orange bg-orange bg-opacity-15'}`}
          onClick={() => handleQuestionType('mcq')}
          type='button'
        >
          MCQ
        </button>
        <button
          className={`w-36 h-9 text-xs mr-5 rounded-sm bg-primary text-orange__primary  hover:text-success hover:bg-success hover:bg-opacity-15 ${selectedQuestionType === 'tf' ? 'bg-success bg-opacity-15 text-success' : 'text-orange bg-orange bg-opacity-15'}`}
          onClick={() => handleQuestionType('tf')}
          type='button'
        >
          T/F
        </button>
      </div>
      <div className='h-10 ml-[10%] mt-5 flex rounded-sm bg-blue w-40'>
        <RHFTextField
          className='text-white  bg-blue w-full pl-2'
          type='number'
          id='marks'
          name='marks'
          min='0'
          max='100'
          step='1'
          placeholder='Marks'
          // control={questionListForm.control}
        />
      </div>
      {selectedQuestionType === 'summary' && (
        <SummaryType questionListForm={questionListForm} />
      )}
      {selectedQuestionType === 'mcq' && (
        <McqType questionListForm={questionListForm} />
      )}
      {selectedQuestionType === 'tf' && (
        <TrueFalseType questionListForm={questionListForm} />
      )}
      <hr className='mt-6 text-grey__primary__light' />
    </div>
  );
};

export default AddQuestionOption;
